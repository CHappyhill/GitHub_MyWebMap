function RedButton_Run() {
  // changeColor('red');
  // document.body.digiclock.color = "black";
  document.getElementById("digiclock").style.color = "yellow";
  document.body.style.background = "red";
  document.getElementById("RedButton").style.fontSize = "100px";
  document.getElementById("RedButton").innerHTML = "Ah you did dare to press the button... Excellent!";
}
